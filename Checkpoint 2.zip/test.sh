#! /bin/sh

VAR=$1

./driver -i "$VAR".txt -s "$VAR".png
